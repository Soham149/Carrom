var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

 var wall1 = createSprite(200, 50, 250, 20);
 var wall2 = createSprite(350, 200,20, 250);
 var wall3 = createSprite(200, 350, 250,20);
 var wall4 = createSprite(50, 200, 20, 250);
 var ball = createSprite(200, 200, 20, 20);
 var hole1 = createSprite(330, 70, 20, 20);
 var hole2 = createSprite(65, 330, 20, 20);
 var hole3 = createSprite(70, 65, 20, 20);
 var hole4 = createSprite(330, 330, 20, 20);
 var ball2 = createSprite(200, 300, 30, 30);
 var ball3 = createSprite(200, 180, 20, 20);
 var ball4 = createSprite(220,190, 20, 20);
 var ball5 = createSprite(220, 210, 20, 20);
 var ball6 = createSprite(180, 210, 20, 20);
 var ball7 = createSprite(180, 190, 20, 20);
 var ball8 = createSprite(200, 220, 20, 20);
 var line1 = createSprite(325, 200, 3,200); 
 var line2 = createSprite(195, 315, 200, 3);
 var line3 = createSprite(80, 200, 3, 200);
 var line4 = createSprite(200, 75, 200, 3);
  
 
 hole1.shapeColor = "black";
 hole2.shapeColor = "black";
 hole3.shapeColor = "black";
 hole4.shapeColor = "black";
 
 line1.shapeColor = "black";
 line2.shapeColor = "black";
 line3.shapeColor = "black";
 line4.shapeColor = "black";
 
 wall1.shapeColor = "blue";
 wall2.shapeColor = "blue";
 wall3.shapeColor = "blue";
 wall4.shapeColor = "blue";
 
 ball.shapeColor = "Red";
 ball2.shapeColor = "Green";
 ball3.shapeColor = "Tan";
 ball5.shapeColor = "Tan";
 ball6.shapeColor = "Tan";
 ball4.shapeColor = "Black";
 ball7.shapeColor = "Black";
 ball8.shapeColor = "Black"; 
 
  ball3.velocityX = 0;
  ball3.velocityY = 0;
  
  ball4.velocityX = 0;
  ball4.velocityY = 0;
  
  ball5.velocityX = 0;
  ball5.velocityY = 0;
  
  ball6.velocityX = 0;
  ball6.velocityY = 0;
  
  ball7.velocityX = 0;
  ball7.velocityY = 0;
  
  ball8.velocityX = 0;
  ball8.velocityY = 0;
  
  ball.velocityX = 0;
  ball.velocityY = 0;
  
  ball2.velocityX = -2;
  ball2.velocityY = 0;
  
   
function draw() {
  background("brown");
  drawSprites();
  createEdgeSprites();

  if (keyDown(UP_ARROW)) {
  ball2.velocityX =0;
  ball2.velocityY = -6;
  }
  if (keyDown(DOWN_ARROW)) {
    ball2.velocityX = 0;
    ball2.velocityY = 6;
  }
  if (keyDown(RIGHT_ARROW)) {
    ball2.velocityX = 6;
    ball2.velocityY = 0;
  }
  if (keyDown(LEFT_ARROW)) {
    ball2.velocityX = -6;
    ball2.velocityY = 0;
  }
   ball.bounce(ball3);
   ball.bounce(ball4);
   ball.bounce(ball5);
   ball.bounce(ball6);
   ball.bounce(ball7);
   ball.bounce(ball8);
   ball.bounce(ball);
   
   ball2.bounce(ball3);
   ball2.bounce(ball4);
   ball2.bounce(ball5);
   ball2.bounce(ball6);
   ball2.bounce(ball7);
   ball2.bounce(ball8);
   ball2.bounce(ball);
   
   ball3.bounce(ball4);
   ball3.bounce(ball5);
   ball3.bounce(ball6);
   ball3.bounce(ball7);
   ball3.bounce(ball8);
   
   ball4.bounce(ball5);
   ball4.bounce(ball6);
   ball4.bounce(ball7);
   ball4.bounce(ball8);
   
   ball5.bounce(ball6);
   ball5.bounce(ball7);
   ball5.bounce(ball8);
   
   ball6.bounce(ball7);
   ball6.bounce(ball8);
   
   ball7.bounce(ball8);
   
   ball.bounceOff(wall1);
   ball.bounceOff(wall2);
   ball.bounceOff(wall3);
   ball.bounceOff(wall4);
   
   ball2.bounceOff(wall1);
   ball2.bounceOff(wall2);
   ball2.bounceOff(wall3);
   ball2.bounceOff(wall4);
   
   ball3.bounceOff(wall1);
   ball3.bounceOff(wall2);
   ball3.bounceOff(wall3);
   ball3.bounceOff(wall4);
   
   ball4.bounceOff(wall1);
   ball4.bounceOff(wall2);
   ball4.bounceOff(wall3);
   ball4.bounceOff(wall4);
   
   ball5.bounceOff(wall1);
   ball5.bounceOff(wall2);
   ball5.bounceOff(wall3);
   ball5.bounceOff(wall4);
   
   ball6.bounceOff(wall1);
   ball6.bounceOff(wall2);
   ball6.bounceOff(wall3);   
   ball6.bounceOff(wall4);
   
   ball7.bounceOff(wall1);
   ball7.bounceOff(wall2);
   ball7.bounceOff(wall3);
   ball7.bounceOff(wall4);
   
   ball8.bounceOff(wall1);
   ball8.bounceOff(wall2);
   ball8.bounceOff(wall3);
   ball8.bounceOff(wall4);
   
//When you touch the holes, you get the point
//When the ball is in the hole, the ball will turn gray
//When the ball goes into the hole, a ball will pop up, and will go away, after sometime
   if (ball.isTouching(hole1)||ball.isTouching(hole2)||ball.isTouching(hole3)||ball.isTouching(hole4)){
      ball.shapeColor = "ed";
      ball.velocityX = 0;
      ball.velocityY = 0;
     }
   if (ball3.isTouching(hole1)||ball3.isTouching(hole2)||ball3.isTouching(hole3)||ball3.isTouching(hole4)){
      ball.shapeColor = "Red";
      ball.velocityX = 0;
      ball.velocityY = 0;
      ball.x = 65;
      ball.y = 375;
} 
  if  (ball4.isTouching(hole1)||ball4.isTouching(hole2)||ball4.isTouching(hole3)||ball4.isTouching(hole4)){
      ball.shapeColor = "Gray";
      ball.velocityX = 0;
      ball.velocityY = 0;
      ball.x = 140;
      ball.y = 375;
}    
  if  (ball5.isTouching(hole1)||ball5.isTouching(hole2)||ball5.isTouching(hole3)||ball5.isTouching(hole4)){
      ball.shapeColor = "Gray";
      ball.velocityX = 0;
      ball.velocityY = 0;
      ball.x = 170;
      ball.y = 375;
}    
  if  (ball6.isTouching(hole1)||ball6.isTouching(hole2)||ball6.isTouching(hole3)||ball6.isTouching(hole4)){
      ball.shapeColor = "Gray";
      ball.velocityX = 0;
      ball.velocityY = 0;
      ball.x = 195;
      ball.y = 375;
}    
  if  (ball7.isTouching(hole1)||ball7.isTouching(hole2)||ball7.isTouching(hole3)||ball7.isTouching(hole4)){
      ball.shapeColor = "Gray";
      ball.velocityX = 0;
      ball.velocityY = 0;
      ball.x = 240;
      ball.y = 375;
    
}    
  if  (ball8.isTouching(hole1)||ball8.isTouching(hole2)||ball8.isTouching(hole3)||ball8.isTouching(hole4)){
      ball.shapeColor = "Gray";
      ball.velocityX = 0;
      ball.velocityY = 0;
      ball.x = 280;
      ball.y = 375;
  }    
}      
      

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
